The folder named `ComputeShader_Plugin` is an Unreal Engine plugin that can be dropped into any UE5 c++ project.

1. Extract the plugin folder to `YourProject/Plugins/` directory.
2. Recompile the project.