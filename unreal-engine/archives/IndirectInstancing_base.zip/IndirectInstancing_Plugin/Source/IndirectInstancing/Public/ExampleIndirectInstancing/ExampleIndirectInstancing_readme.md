# ExampleIndirectInstancing usage

## World

1. Open the "Add Actors" panel and search for "Example Indirect Instancing"
2. Drag and drop that actor into your world
3. Enjoy, and get digging into the code

## Notes

-   Shadows are broken until UE 5.1. See: https://github.com/EpicGames/UnrealEngine/blob/d11782b9046e9d0b130309591e4efc57f4b8b037/Engine/Plugins/Experimental/VirtualHeightfieldMesh/Source/VirtualHeightfieldMesh/Private/VirtualHeightfieldMeshSceneProxy.cpp#L538
-   The mesh will flicker as you move it.

Feel free to delete this file
