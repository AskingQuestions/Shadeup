# ExampleComputeShader usage

## Blueprint

1. Right-click in any blueprint editor and add the node: "Execute RTCompute Shader"
2. Pass in a render target
3. Enjoy, and get digging into the code

Find the main shader code under `Plugin/Shaders/Module/Private/ExampleComputeShader/ExampleComputeShader.usf`

Feel free to delete this file
