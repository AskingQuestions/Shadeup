# ExampleMaterialNodeOutput usage

## Material Graph

1. Right-click and search for "Shadeup" and add the relevant node
2. Enjoy, and get digging into the code

Feel free to delete this file
